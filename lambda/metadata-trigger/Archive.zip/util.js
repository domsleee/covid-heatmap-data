const axios = require('axios');
const DATA_URL = 'https://data.nsw.gov.au/data/api/3/action/package_show?id=aefcde60-3b0c-4bc0-9af1-6fe652944ec2';

/**
 * 
 * @param {*} dataJson 
 * @param {*} meta 
 * @returns 
 */
function checkMetadata(dataJson, meta) {
  const resource = dataJson.resources[0];
  const resourceDate = new Date(resource['created']);
  const metaDate = meta?.date;

  console.log(`resourceDate: ${resourceDate} vs ${metaDate}`);
  return {
    'needsUpdating': resourceDate != meta?.date
  };
}

async function getCaseData() {
  const res = await axios.get(DATA_URL);
  return res.data.result;
}

module.exports = {checkMetadata, getCaseData};